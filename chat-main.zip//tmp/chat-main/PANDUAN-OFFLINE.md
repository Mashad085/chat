# ChatApp — Panduan Jaringan Lokal (Offline)


## Cara Cepat — Linux ARM (Raspberry Pi, Oracle ARM, dll)

```bash
# 1. Beri izin eksekusi (sekali saja)
chmod +x setup.sh start.sh

# 2. Setup (sekali saja)
./setup.sh

# 3. Jalankan setiap saat
./start.sh
```

## Install Node.js di Linux ARM

Jika belum ada Node.js:

```bash
# Debian / Ubuntu / Raspberry Pi OS
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt-get install -y nodejs

# Verifikasi
node -v && npm -v
```


## Cara Cepat (Windows)

```
1. Jalankan setup.bat  (sekali saja)
2. Jalankan start.bat  (setiap mau pakai)
3. Buka browser: http://localhost:3000
```

---

## Cara Manual

```bash
npm install
npm start
```

---

## Akses dari HP / Perangkat Lain (Satu WiFi)

1. Jalankan server di komputer
2. Lihat IP komputer (muncul di `start.bat`, atau cek via `ipconfig`)
3. Di HP, buka browser → `http://192.168.x.x:3000`

> Pastikan komputer dan HP terhubung ke WiFi / LAN yang sama.

---

## Fitur Panggilan Offline

ChatApp menggunakan **TURN/STUN server lokal** (port 3478) yang berjalan di komputer yang sama dengan server. Tidak ada koneksi ke server eksternal sama sekali.

### Konfigurasi TURN (opsional)

Edit file `.env`:

```
TURN_PORT=3478
TURN_USER=chatapp
TURN_PASSWORD=chatapp123

# Set IP manual jika deteksi otomatis salah:
# TURN_PUBLIC_IP=192.168.1.100
```

### Syarat Panggilan Antar Perangkat

| Skenario | Berhasil? |
|---|---|
| Browser ke browser di komputer yang sama | ✅ |
| HP ke komputer (satu WiFi) | ✅ dengan TURN lokal |
| HP ke HP (satu WiFi) | ✅ dengan TURN lokal |
| Beda jaringan (internet) | ❌ hanya lokal |

### Catatan HTTPS

Browser memerlukan HTTPS untuk akses kamera/mikrofon **kecuali** di `localhost`.

- `localhost` → langsung bisa tanpa HTTPS
- IP lokal (192.168.x.x) di Chrome → perlu tambahkan ke daftar pengecualian:
  - Buka `chrome://flags/#unsafely-treat-insecure-origin-as-secure`
  - Tambah `http://192.168.x.x:3000`
  - Klik Enable → Relaunch

---

## Port yang Digunakan

| Port | Fungsi |
|---|---|
| 3000 | ChatApp web server |
| 3478 (UDP+TCP) | TURN/STUN lokal untuk panggilan |

Pastikan Windows Firewall mengizinkan port ini jika akses dari perangkat lain.

---

## Akun Default

| Username | Password | Role |
|---|---|---|
| admin | admin123 | Admin |
