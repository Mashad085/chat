require('dotenv').config();
const http = require('http');
const { Server } = require('socket.io');
const { createApp }  = require('./app');
const { initDB }     = require('./src/config/database');
const { initRedis }  = require('./src/config/redis');
const { initBroker, closeBroker } = require('./src/services/broker');
const { initSocket } = require('./src/services/socket');
const { initTurn, stopTurn }   = require('./src/services/turn');
const logger         = require('./src/utils/logger');

async function start() {
  // 1. Database (wajib)
  await initDB();

  // 2. Redis (opsional — fallback ke memory jika tidak ada)
  try {
    await initRedis();
  } catch (e) {
    logger.warn('[server] Redis tidak tersedia, lanjut dengan in-memory store');
  }

  // 3. Broker (opsional — pakai in-process jika RabbitMQ tidak ada)
  try {
    await initBroker();
  } catch (e) {
    logger.warn('[server] Broker init gagal: ' + e.message);
  }

  // 4. TURN/STUN server lokal (untuk panggilan offline)
  try {
    await initTurn();
  } catch (e) {
    logger.warn('[server] TURN server tidak bisa distart: ' + e.message);
  }

  const app    = createApp();
  const server = http.createServer(app);
  const io     = new Server(server, {
    cors: { origin: '*', credentials: true },
    pingTimeout: 60000,
    pingInterval: 25000,
  });

  initSocket(io);

  const PORT = parseInt(process.env.PORT || '3000');
  server.listen(PORT, () => {
    logger.info('\n' + '─'.repeat(52));
    logger.info(`  🚀  ChatApp  →  http://localhost:${PORT}`);
    logger.info(`  🛡️   Admin   →  http://localhost:${PORT}/admin`);
    logger.info(`  👤  Login   →  admin / admin123`);
    logger.info('─'.repeat(52) + '\n');
  });

  const stop = async () => {
    server.close(async () => {
      try { await closeBroker(); } catch {}
      try { stopTurn(); } catch {}
      process.exit(0);
    });
  };
  process.on('SIGTERM', stop);
  process.on('SIGINT',  stop);
}

start().catch(e => {
  console.error('[server] Fatal error:', e.message);
  console.error(e.stack);
  process.exit(1);
});
