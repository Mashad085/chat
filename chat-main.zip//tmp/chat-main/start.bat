@echo off
title ChatApp Server
color 0A

:: Copy .env if not exists
if not exist ".env" (
    copy "1.env.1" ".env" >nul
)

echo.
echo  ========================================
echo    ChatApp - Server Lokal
echo  ========================================
echo.
echo  Mendeteksi IP jaringan lokal...
echo.

:: Show local IPs so user knows where to connect from other devices
for /f "tokens=2 delims=:" %%a in ('ipconfig ^| findstr /i "IPv4"') do (
    set IP=%%a
    setlocal enabledelayedexpansion
    set IP=!IP: =!
    echo  Alamat IP: !IP!
    endlocal
)

echo.
echo  Akses ChatApp:
echo    - Komputer ini  : http://localhost:3000
echo    - HP / Tab (WiFi): http://[IP-diatas]:3000
echo.
echo  Admin panel : http://localhost:3000/admin
echo  Login admin : admin / admin123
echo.
echo  TURN/STUN server lokal aktif di port 3478
echo  Panggilan bekerja 100%% OFFLINE (tanpa internet)
echo.
echo  ========================================
echo  Tekan Ctrl+C untuk menghentikan server
echo  ========================================
echo.

node server.js

pause
