#!/bin/bash
# setup.sh — ChatApp setup untuk Linux (ARM / x64)
set -e

GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

echo ""
echo "════════════════════════════════════════"
echo "  ChatApp — Setup Linux"
echo "════════════════════════════════════════"
echo ""

# Check Node.js
if ! command -v node &> /dev/null; then
    echo -e "${RED}[ERROR] Node.js belum terinstall!${NC}"
    echo ""
    echo "Install Node.js di Linux ARM:"
    echo ""
    echo "  # Debian/Ubuntu/Raspberry Pi OS:"
    echo "  curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -"
    echo "  sudo apt-get install -y nodejs"
    echo ""
    echo "  # Atau pakai nvm:"
    echo "  curl -o- https://raw.githubusercontent.com/nvm-sh/nvm/v0.39.0/install.sh | bash"
    echo "  source ~/.bashrc && nvm install 20 && nvm use 20"
    echo ""
    exit 1
fi

NODE_VER=$(node -v)
echo -e "${GREEN}[OK]${NC} Node.js: $NODE_VER"

# Check npm
if ! command -v npm &> /dev/null; then
    echo -e "${RED}[ERROR] npm tidak ditemukan${NC}"
    exit 1
fi
echo -e "${GREEN}[OK]${NC} npm: $(npm -v)"
echo ""

# Copy .env
if [ ! -f ".env" ]; then
    cp 1.env.1 .env
    echo -e "${GREEN}[OK]${NC} File .env dibuat"
else
    echo -e "${GREEN}[OK]${NC} File .env sudah ada"
fi

# Create data & logs dir
mkdir -p data logs
echo -e "${GREEN}[OK]${NC} Direktori data/ dan logs/ siap"
echo ""

# Install dependencies
echo -e "${YELLOW}[INFO]${NC} Menginstall dependencies..."
echo "       (ini mungkin butuh beberapa menit di ARM)"
echo ""
npm install

echo ""
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo -e "${GREEN}  Setup selesai! Jalankan: ./start.sh${NC}"
echo -e "${GREEN}════════════════════════════════════════${NC}"
echo ""
