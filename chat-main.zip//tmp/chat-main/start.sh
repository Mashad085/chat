#!/bin/bash
# start.sh — ChatApp server untuk Linux (ARM / x64)

GREEN='\033[0;32m'
CYAN='\033[0;36m'
YELLOW='\033[1;33m'
NC='\033[0m'

# Copy .env jika belum ada
if [ ! -f ".env" ]; then
    cp 1.env.1 .env
fi

# Buat direktori yang dibutuhkan
mkdir -p data logs public/uploads

# Deteksi semua IP lokal
echo ""
echo -e "${CYAN}════════════════════════════════════════${NC}"
echo -e "${CYAN}  ChatApp — Server Lokal${NC}"
echo -e "${CYAN}════════════════════════════════════════${NC}"
echo ""
echo "  IP jaringan aktif:"

# Tampilkan semua interface dengan IP
ip addr show 2>/dev/null | grep -E "inet [0-9]" | grep -v "127.0.0.1" | while read -r line; do
    IP=$(echo "$line" | awk '{print $2}' | cut -d'/' -f1)
    IFACE=$(echo "$line" | awk '{print $NF}' 2>/dev/null || echo "")
    echo -e "    ${GREEN}${IP}${NC}  (${IFACE})"
done

# Fallback jika ip tidak tersedia
if ! command -v ip &> /dev/null; then
    hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^$' | while read -r IP; do
        echo -e "    ${GREEN}${IP}${NC}"
    done
fi

echo ""
echo "  Akses ChatApp:"
echo -e "    - Komputer ini  : ${GREEN}http://localhost:3000${NC}"
echo -e "    - HP / Tab      : ${GREEN}http://[IP-diatas]:3000${NC}"
echo ""
echo "  Admin panel  : http://localhost:3000/admin"
echo "  Login admin  : admin / admin123"
echo ""
echo "  TURN/STUN lokal : port 3478 (UDP+TCP)"
echo "  Mode panggilan  : 100% OFFLINE"
echo ""
echo -e "${CYAN}════════════════════════════════════════${NC}"
echo "  Tekan Ctrl+C untuk menghentikan"
echo -e "${CYAN}════════════════════════════════════════${NC}"
echo ""

# Jalankan server
node server.js
