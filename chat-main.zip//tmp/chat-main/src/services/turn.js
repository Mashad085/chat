/**
 * src/services/turn.js
 *
 * STUN + TURN server — pure Node.js, zero native addons
 * Kompatibel: Linux x64, ARM (Raspberry Pi, Oracle ARM, dll), Windows
 * 100% offline — tidak butuh internet
 *
 * Protokol: RFC 5389 (STUN), RFC 5766 (TURN) — subset minimal
 * Transport: UDP (STUN binding + TURN relay), TCP (STUN binding)
 */

'use strict';

const dgram  = require('dgram');
const net    = require('net');
const crypto = require('crypto');
const os     = require('os');
const logger = require('../utils/logger');

// ─── KONFIGURASI ────────────────────────────────────────
const TURN_PORT     = parseInt(process.env.TURN_PORT     || '3478');
const TURN_USER     = process.env.TURN_USER              || 'chatapp';
const TURN_PASSWORD = process.env.TURN_PASSWORD          || 'chatapp123';
const TURN_REALM    = process.env.TURN_REALM             || 'chatapp.local';
let   serverIp      = process.env.TURN_PUBLIC_IP         || null;

// ─── STUN CONSTANTS ─────────────────────────────────────
const STUN_MAGIC        = 0x2112A442;
const STUN_BINDING_REQ  = 0x0001;
const STUN_BINDING_RESP = 0x0101;
const STUN_BINDING_ERR  = 0x0111;
const STUN_ALLOC_REQ    = 0x0003;
const STUN_ALLOC_RESP   = 0x0103;
const STUN_ALLOC_ERR    = 0x0113;
const STUN_REFRESH_REQ  = 0x0004;
const STUN_REFRESH_RESP = 0x0104;
const STUN_SEND_IND     = 0x0016;
const STUN_DATA_IND     = 0x0017;
const STUN_CREATEPERM   = 0x0008;
const STUN_CREATEPERM_R = 0x0108;
const STUN_CHANDBIND_REQ= 0x0009;
const STUN_CHANDBIND_R  = 0x0109;

const ATTR_MAPPED_ADDR      = 0x0001;
const ATTR_USERNAME         = 0x0006;
const ATTR_MESSAGE_INTEG    = 0x0008;
const ATTR_ERROR_CODE       = 0x0009;
const ATTR_UNKNOWN_ATTR     = 0x000A;
const ATTR_REALM            = 0x0014;
const ATTR_NONCE            = 0x0015;
const ATTR_XOR_MAPPED_ADDR  = 0x0020;
const ATTR_SOFTWARE         = 0x8022;
const ATTR_FINGERPRINT      = 0x8028;
const ATTR_LIFETIME         = 0x000D;
const ATTR_XOR_PEER_ADDR    = 0x0012;
const ATTR_DATA             = 0x0013;
const ATTR_XOR_RELAYED_ADDR = 0x0016;
const ATTR_CHANNEL_NUMBER   = 0x000C;

// ─── HELPERS ────────────────────────────────────────────
function getLocalIp() {
  const nets = os.networkInterfaces();
  for (const name of Object.keys(nets)) {
    for (const n of nets[name]) {
      if (n.family === 'IPv4' && !n.internal) return n.address;
    }
  }
  return '127.0.0.1';
}

function generateNonce() {
  return crypto.randomBytes(16).toString('hex');
}

function hmacSha1(key, data) {
  return crypto.createHmac('sha1', key).update(data).digest();
}

function crc32(buf) {
  let crc = 0xFFFFFFFF;
  for (let i = 0; i < buf.length; i++) {
    crc ^= buf[i];
    for (let j = 0; j < 8; j++) {
      crc = (crc >>> 1) ^ (crc & 1 ? 0xEDB88320 : 0);
    }
  }
  return (crc ^ 0xFFFFFFFF) >>> 0;
}

// ─── STUN MESSAGE PARSER ────────────────────────────────
function parseStun(buf) {
  if (buf.length < 20) return null;
  const type      = buf.readUInt16BE(0);
  const length    = buf.readUInt16BE(2);
  const magic     = buf.readUInt32BE(4);
  const txId      = buf.slice(8, 20);
  if (magic !== STUN_MAGIC) return null;

  const attrs = {};
  let offset = 20;
  while (offset < 20 + length && offset < buf.length) {
    const aType = buf.readUInt16BE(offset);
    const aLen  = buf.readUInt16BE(offset + 2);
    const aVal  = buf.slice(offset + 4, offset + 4 + aLen);
    attrs[aType] = aVal;
    offset += 4 + aLen + (4 - (aLen % 4)) % 4; // padding
  }
  return { type, length, txId, attrs };
}

// ─── STUN MESSAGE BUILDER ───────────────────────────────
function buildStun(type, txId, attrs) {
  const parts = [];
  for (const [aType, aVal] of attrs) {
    const padded = Buffer.alloc(4 + aVal.length + ((4 - (aVal.length % 4)) % 4));
    padded.writeUInt16BE(aType, 0);
    padded.writeUInt16BE(aVal.length, 2);
    aVal.copy(padded, 4);
    parts.push(padded);
  }
  const body = Buffer.concat(parts);
  const hdr  = Buffer.alloc(20);
  hdr.writeUInt16BE(type, 0);
  hdr.writeUInt16BE(body.length, 2);
  hdr.writeUInt32BE(STUN_MAGIC, 4);
  txId.copy(hdr, 8);
  return Buffer.concat([hdr, body]);
}

function xorAddr(ip, port, txId) {
  const xPort = port ^ (STUN_MAGIC >>> 16);
  const ipParts = ip.split('.').map(Number);
  const magicBuf = Buffer.alloc(4);
  magicBuf.writeUInt32BE(STUN_MAGIC, 0);
  const xBuf = Buffer.alloc(8);
  xBuf.writeUInt8(0, 0);
  xBuf.writeUInt8(1, 1); // IPv4 family
  xBuf.writeUInt16BE(xPort, 2);
  for (let i = 0; i < 4; i++) xBuf.writeUInt8(ipParts[i] ^ magicBuf[i], 4 + i);
  return xBuf;
}

function encodeString(s) { return Buffer.from(s, 'utf8'); }
function encodeU32(v) { const b = Buffer.alloc(4); b.writeUInt32BE(v, 0); return b; }
function encodeErrorCode(code, reason) {
  const b = Buffer.alloc(4 + reason.length);
  b.writeUInt16BE(0, 0);
  b.writeUInt8(Math.floor(code / 100), 2);
  b.writeUInt8(code % 100, 3);
  Buffer.from(reason).copy(b, 4);
  return b;
}

// ─── AUTH ────────────────────────────────────────────────
const nonces = new Map(); // nonce → { created }

function freshNonce() {
  const n = generateNonce();
  nonces.set(n, { created: Date.now() });
  return n;
}

function validNonce(n) {
  const e = nonces.get(n);
  if (!e) return false;
  if (Date.now() - e.created > 3600000) { nonces.delete(n); return false; }
  return true;
}

function getLongTermKey(username, realm, password) {
  return crypto.createHash('md5').update(`${username}:${realm}:${password}`).digest();
}

function verifyMessageIntegrity(msg, attrs, password) {
  try {
    const userAttr  = attrs[ATTR_USERNAME];
    const realmAttr = attrs[ATTR_REALM];
    const miAttr    = attrs[ATTR_MESSAGE_INTEG];
    if (!userAttr || !realmAttr || !miAttr) return false;

    const user  = userAttr.toString();
    const realm = realmAttr.toString();
    const key   = getLongTermKey(user, realm, password);

    // Reconstruct message up to (not including) MESSAGE-INTEGRITY attr
    // Find offset of MESSAGE-INTEGRITY in original message
    let offset = 20;
    let miOffset = -1;
    while (offset < msg.length - 4) {
      const t = msg.readUInt16BE(offset);
      const l = msg.readUInt16BE(offset + 2);
      if (t === ATTR_MESSAGE_INTEG) { miOffset = offset; break; }
      offset += 4 + l + ((4 - l % 4) % 4);
    }
    if (miOffset < 0) return false;

    const msgForHmac = Buffer.from(msg);
    const newLen = miOffset - 20 + 24; // up to and including MI attr header+value
    msgForHmac.writeUInt16BE(newLen, 2);
    const expected = hmacSha1(key, msgForHmac.slice(0, miOffset));
    return expected.equals(miAttr);
  } catch(e) { return false; }
}

// ─── ALLOCATIONS (TURN relay) ────────────────────────────
const allocations = new Map(); // key → { socket, ip, port, lifetime, permissions, channels }

function cleanAllocations() {
  const now = Date.now();
  for (const [key, alloc] of allocations) {
    if (now > alloc.expires) {
      try { alloc.socket.close(); } catch {}
      allocations.delete(key);
    }
  }
}

// ─── UDP SERVER ──────────────────────────────────────────
let udpServer  = null;
let tcpServer  = null;
let cleanTimer = null;

function handleStunUdp(buf, rinfo, socket) {
  const msg = parseStun(buf);
  if (!msg) return;

  const { type, txId, attrs } = msg;

  // ── STUN Binding (just reflect XOR-MAPPED-ADDRESS) ──
  if (type === STUN_BINDING_REQ) {
    const resp = buildStun(STUN_BINDING_RESP, txId, [
      [ATTR_XOR_MAPPED_ADDR, xorAddr(rinfo.address, rinfo.port, txId)],
      [ATTR_SOFTWARE, encodeString('ChatApp-STUN/1.0')],
    ]);
    socket.send(resp, rinfo.port, rinfo.address);
    return;
  }

  // ── TURN Allocate ──
  if (type === STUN_ALLOC_REQ) {
    const nonceAttr = attrs[ATTR_NONCE];
    const userAttr  = attrs[ATTR_USERNAME];
    const realmAttr = attrs[ATTR_REALM];

    // Step 1: demand auth
    if (!nonceAttr || !userAttr || !realmAttr) {
      const nonce = freshNonce();
      const err = buildStun(STUN_ALLOC_ERR, txId, [
        [ATTR_ERROR_CODE, encodeErrorCode(401, 'Unauthorized')],
        [ATTR_REALM,      encodeString(TURN_REALM)],
        [ATTR_NONCE,      encodeString(nonce)],
        [ATTR_SOFTWARE,   encodeString('ChatApp-TURN/1.0')],
      ]);
      socket.send(err, rinfo.port, rinfo.address);
      return;
    }

    // Step 2: check credentials
    const nonce = nonceAttr.toString();
    const user  = userAttr.toString().split(':').pop(); // strip timestamp if any
    if (!validNonce(nonce) || user !== TURN_USER) {
      const newNonce = freshNonce();
      const err = buildStun(STUN_ALLOC_ERR, txId, [
        [ATTR_ERROR_CODE, encodeErrorCode(401, 'Unauthorized')],
        [ATTR_REALM,      encodeString(TURN_REALM)],
        [ATTR_NONCE,      encodeString(newNonce)],
      ]);
      socket.send(err, rinfo.port, rinfo.address);
      return;
    }

    if (!verifyMessageIntegrity(buf, attrs, TURN_PASSWORD)) {
      const err = buildStun(STUN_ALLOC_ERR, txId, [
        [ATTR_ERROR_CODE, encodeErrorCode(401, 'Bad credentials')],
        [ATTR_REALM,      encodeString(TURN_REALM)],
        [ATTR_NONCE,      encodeString(freshNonce())],
      ]);
      socket.send(err, rinfo.port, rinfo.address);
      return;
    }

    // Create relay socket on random UDP port
    const allocKey = `${rinfo.address}:${rinfo.port}`;
    if (allocations.has(allocKey)) {
      try { allocations.get(allocKey).socket.close(); } catch {}
    }

    const relaySocket = dgram.createSocket('udp4');
    relaySocket.bind(0, serverIp, () => {
      const relayPort = relaySocket.address().port;
      const lifetime  = 600; // seconds

      const alloc = {
        socket:      relaySocket,
        ip:          serverIp,
        port:        relayPort,
        clientIp:    rinfo.address,
        clientPort:  rinfo.port,
        expires:     Date.now() + lifetime * 1000,
        permissions: new Set(),
        channels:    new Map(),
      };
      allocations.set(allocKey, alloc);

      // Forward data from relay socket back to client
      relaySocket.on('message', (data, peer) => {
        const ch = alloc.channels.get(`${peer.address}:${peer.port}`);
        if (ch !== undefined) {
          // Channel data
          const chanBuf = Buffer.alloc(4 + data.length);
          chanBuf.writeUInt16BE(ch, 0);
          chanBuf.writeUInt16BE(data.length, 2);
          data.copy(chanBuf, 4);
          socket.send(chanBuf, alloc.clientPort, alloc.clientIp);
        } else if (alloc.permissions.has(peer.address)) {
          // Data indication
          const ind = buildStun(STUN_DATA_IND, crypto.randomBytes(12), [
            [ATTR_XOR_PEER_ADDR, xorAddr(peer.address, peer.port, txId)],
            [ATTR_DATA,          data],
          ]);
          socket.send(ind, alloc.clientPort, alloc.clientIp);
        }
      });

      const resp = buildStun(STUN_ALLOC_RESP, txId, [
        [ATTR_XOR_RELAYED_ADDR, xorAddr(serverIp, relayPort, txId)],
        [ATTR_XOR_MAPPED_ADDR,  xorAddr(rinfo.address, rinfo.port, txId)],
        [ATTR_LIFETIME,         encodeU32(lifetime)],
        [ATTR_SOFTWARE,         encodeString('ChatApp-TURN/1.0')],
      ]);
      socket.send(resp, rinfo.port, rinfo.address);
    });
    relaySocket.on('error', () => {});
    return;
  }

  // ── TURN Refresh ──
  if (type === STUN_REFRESH_REQ) {
    const allocKey = `${rinfo.address}:${rinfo.port}`;
    const alloc = allocations.get(allocKey);
    const lifetime = attrs[ATTR_LIFETIME] ? attrs[ATTR_LIFETIME].readUInt32BE(0) : 600;
    if (alloc) {
      if (lifetime === 0) {
        try { alloc.socket.close(); } catch {}
        allocations.delete(allocKey);
      } else {
        alloc.expires = Date.now() + lifetime * 1000;
      }
    }
    const resp = buildStun(STUN_REFRESH_RESP, txId, [
      [ATTR_LIFETIME, encodeU32(lifetime)],
    ]);
    socket.send(resp, rinfo.port, rinfo.address);
    return;
  }

  // ── Create Permission ──
  if (type === STUN_CREATEPERM) {
    const allocKey = `${rinfo.address}:${rinfo.port}`;
    const alloc = allocations.get(allocKey);
    if (alloc && attrs[ATTR_XOR_PEER_ADDR]) {
      const peerBuf = attrs[ATTR_XOR_PEER_ADDR];
      const xPort = peerBuf.readUInt16BE(2) ^ (STUN_MAGIC >>> 16);
      const magicBuf = Buffer.alloc(4); magicBuf.writeUInt32BE(STUN_MAGIC, 0);
      const peerIp = [0,1,2,3].map(i => peerBuf[4+i] ^ magicBuf[i]).join('.');
      alloc.permissions.add(peerIp);
    }
    const resp = buildStun(STUN_CREATEPERM_R, txId, []);
    socket.send(resp, rinfo.port, rinfo.address);
    return;
  }

  // ── Channel Bind ──
  if (type === STUN_CHANDBIND_REQ) {
    const allocKey = `${rinfo.address}:${rinfo.port}`;
    const alloc = allocations.get(allocKey);
    if (alloc && attrs[ATTR_CHANNEL_NUMBER] && attrs[ATTR_XOR_PEER_ADDR]) {
      const chanNum = attrs[ATTR_CHANNEL_NUMBER].readUInt16BE(0);
      const peerBuf = attrs[ATTR_XOR_PEER_ADDR];
      const xPort   = peerBuf.readUInt16BE(2) ^ (STUN_MAGIC >>> 16);
      const magicBuf = Buffer.alloc(4); magicBuf.writeUInt32BE(STUN_MAGIC, 0);
      const peerIp   = [0,1,2,3].map(i => peerBuf[4+i] ^ magicBuf[i]).join('.');
      alloc.channels.set(`${peerIp}:${xPort}`, chanNum);
      alloc.permissions.add(peerIp);
    }
    const resp = buildStun(STUN_CHANDBIND_R, txId, []);
    socket.send(resp, rinfo.port, rinfo.address);
    return;
  }

  // ── Send Indication (relay data to peer) ──
  if (type === STUN_SEND_IND) {
    const allocKey = `${rinfo.address}:${rinfo.port}`;
    const alloc = allocations.get(allocKey);
    if (!alloc || !attrs[ATTR_XOR_PEER_ADDR] || !attrs[ATTR_DATA]) return;
    const peerBuf = attrs[ATTR_XOR_PEER_ADDR];
    const xPort   = peerBuf.readUInt16BE(2) ^ (STUN_MAGIC >>> 16);
    const magicBuf = Buffer.alloc(4); magicBuf.writeUInt32BE(STUN_MAGIC, 0);
    const peerIp  = [0,1,2,3].map(i => peerBuf[4+i] ^ magicBuf[i]).join('.');
    alloc.socket.send(attrs[ATTR_DATA], xPort, peerIp);
    return;
  }

  // ── Channel Data ──
  if (buf.length >= 4 && (buf[0] & 0xC0) === 0x40) {
    const chanNum = buf.readUInt16BE(0);
    const dataLen = buf.readUInt16BE(2);
    const data    = buf.slice(4, 4 + dataLen);
    const allocKey = `${rinfo.address}:${rinfo.port}`;
    const alloc = allocations.get(allocKey);
    if (!alloc) return;
    for (const [peerKey, ch] of alloc.channels) {
      if (ch === chanNum) {
        const [pIp, pPort] = peerKey.split(':');
        alloc.socket.send(data, parseInt(pPort), pIp);
        return;
      }
    }
  }
}

// ─── INIT ────────────────────────────────────────────────
async function initTurn() {
  if (!serverIp) serverIp = getLocalIp();

  return new Promise((resolve, reject) => {
    udpServer = dgram.createSocket('udp4');

    udpServer.on('message', (buf, rinfo) => {
      try { handleStunUdp(buf, rinfo, udpServer); } catch(e) {}
    });

    udpServer.on('error', (e) => {
      if (e.code === 'EADDRINUSE') {
        logger.warn(`[turn] Port ${TURN_PORT} sudah dipakai — skip TURN server`);
        udpServer = null;
        resolve(false);
      } else {
        logger.warn('[turn] UDP error: ' + e.message);
      }
    });

    udpServer.bind(TURN_PORT, '0.0.0.0', () => {
      // TCP server untuk STUN binding over TCP
      tcpServer = net.createServer((conn) => {
        let buf = Buffer.alloc(0);
        conn.on('data', (chunk) => {
          buf = Buffer.concat([buf, chunk]);
          while (buf.length >= 4) {
            const len = buf.readUInt16BE(2);
            if (buf.length < 20 + len) break;
            const msg = buf.slice(0, 20 + len);
            buf = buf.slice(20 + len);
            const parsed = parseStun(msg);
            if (!parsed) continue;
            if (parsed.type === STUN_BINDING_REQ) {
              const addr = conn.remoteAddress?.replace('::ffff:','') || '0.0.0.0';
              const port = conn.remotePort || 0;
              const resp = buildStun(STUN_BINDING_RESP, parsed.txId, [
                [ATTR_XOR_MAPPED_ADDR, xorAddr(addr, port, parsed.txId)],
                [ATTR_SOFTWARE,        encodeString('ChatApp-STUN/1.0')],
              ]);
              try { conn.write(resp); } catch {}
            }
          }
        });
        conn.on('error', () => {});
      });

      tcpServer.on('error', (e) => {
        logger.warn('[turn] TCP error: ' + e.message);
      });

      tcpServer.listen(TURN_PORT, '0.0.0.0', () => {
        logger.info(`[turn] ✅ STUN/TURN server aktif — ${serverIp}:${TURN_PORT} (UDP+TCP)`);
        logger.info(`[turn]    User: ${TURN_USER}  Pass: ${TURN_PASSWORD}`);
        logger.info(`[turn]    Mode: OFFLINE — 100% lokal, tanpa internet`);

        // Cleanup expired allocations every 60s
        cleanTimer = setInterval(cleanAllocations, 60000);

        resolve(true);
      });
    });
  });
}

function stopTurn() {
  clearInterval(cleanTimer);
  for (const [, alloc] of allocations) {
    try { alloc.socket.close(); } catch {}
  }
  allocations.clear();
  try { if (udpServer) udpServer.close(); } catch {}
  try { if (tcpServer) tcpServer.close(); } catch {}
  logger.info('[turn] STUN/TURN server dihentikan');
}

function getIceConfig() {
  const base = `${serverIp}:${TURN_PORT}`;
  return {
    iceServers: [
      // STUN lokal
      { urls: `stun:${base}` },
      // TURN lokal UDP
      { urls: `turn:${base}`, username: TURN_USER, credential: TURN_PASSWORD },
      // TURN lokal TCP
      { urls: `turn:${base}?transport=tcp`, username: TURN_USER, credential: TURN_PASSWORD },
    ],
  };
}

module.exports = { initTurn, stopTurn, getIceConfig, TURN_PORT, TURN_USER, TURN_PASSWORD };
