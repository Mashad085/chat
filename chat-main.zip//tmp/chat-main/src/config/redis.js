/**
 * src/config/redis.js
 * Redis via ioredis — dengan fallback in-memory otomatis
 * Jika Redis tidak tersedia (misal di Windows tanpa Redis),
 * semua fungsi tetap berjalan menggunakan Map di memori.
 */
const logger = require('../utils/logger');

let useMemory = false;

// ─── IN-MEMORY STORE ─────────────────────────────────────
const memStore  = new Map(); // key → { value, expiresAt }
const memHashes = new Map(); // key → Map(field → value)
const memSets   = new Map(); // key → Set

function memSet(key, value, ttl) {
  memStore.set(key, { value: String(value), expiresAt: ttl ? Date.now() + ttl * 1000 : null });
}
function memGet(key) {
  const e = memStore.get(key);
  if (!e) return null;
  if (e.expiresAt && Date.now() > e.expiresAt) { memStore.delete(key); return null; }
  return e.value;
}
function memDel(key) { memStore.delete(key); memHashes.delete(key); memSets.delete(key); }
function memIncr(key) { const v = parseInt(memGet(key)||'0')+1; memSet(key, v); return v; }
function memExpire(key, s) { const e=memStore.get(key); if(e) e.expiresAt=Date.now()+s*1000; }
function memHset(key, field, val) { if(!memHashes.has(key)) memHashes.set(key,new Map()); memHashes.get(key).set(field,val); }
function memHget(key, field) { return memHashes.get(key)?.get(field)??null; }
function memHgetall(key) {
  const h=memHashes.get(key); if(!h) return null;
  const o={}; h.forEach((v,k)=>{if(k!=='__exp')o[k]=v;}); return Object.keys(o).length?o:null;
}
function memHdel(key, field) { memHashes.get(key)?.delete(field); }
function memSadd(key, ...m) { if(!memSets.has(key)) memSets.set(key,new Set()); m.forEach(x=>memSets.get(key).add(x)); }
function memSmembers(key) { return [...(memSets.get(key)||[])]; }
function memSrem(key, m) { memSets.get(key)?.delete(m); }
function memKeys(pattern) {
  const rx=new RegExp('^'+pattern.replace(/\*/g,'.*')+'$');
  return [...new Set([...memStore.keys(),...memHashes.keys(),...memSets.keys()])].filter(k=>rx.test(k));
}

// ─── REDIS CLIENT ─────────────────────────────────────────
let client = null;
let subscriber = null;

async function initRedis() {
  const url = process.env.REDIS_URL || 'redis://localhost:6379';

  if (process.env.NO_REDIS === 'true') {
    logger.warn('[redis] NO_REDIS=true — menggunakan in-memory store');
    useMemory = true;
    return;
  }

  try {
    const Redis = require('ioredis');

    client = new Redis(url, {
      lazyConnect: true,
      connectTimeout: 3000,
      retryStrategy: (times) => {
        if (times > 2) { useMemory = true; return null; }
        return Math.min(times * 200, 1000);
      },
      maxRetriesPerRequest: 1,
    });

    subscriber = new Redis(url, {
      lazyConnect: true,
      connectTimeout: 3000,
      retryStrategy: (times) => times > 2 ? null : Math.min(times * 200, 1000),
    });

    client.on('connect', () => logger.info('[redis] Connected ✓'));
    client.on('error',   (e) => { if (!useMemory) logger.warn('[redis] ' + e.message); });

    await Promise.race([
      client.connect(),
      new Promise((_,rej) => setTimeout(()=>rej(new Error('timeout')), 3500)),
    ]);
    await subscriber.connect();
    logger.info('[redis] Ready');

  } catch (err) {
    logger.warn(`[redis] Tidak dapat terhubung (${err.message}) — fallback ke in-memory`);
    useMemory = true;
    client = null;
    subscriber = null;
  }
}

function getClient()     { return client; }
function getSubscriber() { return subscriber; }

// ─── CACHE ────────────────────────────────────────────────
const Cache = {
  async set(key, value, ttl=3600) {
    if (useMemory) { memSet(key, typeof value==='object'?JSON.stringify(value):String(value), ttl); return; }
    const v=typeof value==='object'?JSON.stringify(value):String(value);
    if (ttl) await client.setex(key,ttl,v); else await client.set(key,v);
  },
  async get(key) {
    if (useMemory) { const v=memGet(key); if(!v)return null; try{return JSON.parse(v);}catch{return v;} }
    const v=await client.get(key); if(!v)return null; try{return JSON.parse(v);}catch{return v;}
  },
  async del(key)             { if(useMemory){memDel(key);return;} return client.del(key); },
  async exists(key)          { if(useMemory) return memGet(key)!==null?1:0; return client.exists(key); },
  async incr(key)            { if(useMemory) return memIncr(key); return client.incr(key); },
  async expire(key,s)        { if(useMemory){memExpire(key,s);return;} return client.expire(key,s); },
  async keys(pattern)        { if(useMemory) return memKeys(pattern); return client.keys(pattern); },
  async hset(key,field,val)  { const v=typeof val==='object'?JSON.stringify(val):val; if(useMemory){memHset(key,field,v);return;} return client.hset(key,field,v); },
  async hget(key,field)      { if(useMemory){const v=memHget(key,field);try{return JSON.parse(v);}catch{return v;}} const v=await client.hget(key,field); try{return JSON.parse(v);}catch{return v;} },
  async hgetall(key)         { if(useMemory) return memHgetall(key); return client.hgetall(key); },
  async hdel(key,field)      { if(useMemory){memHdel(key,field);return;} return client.hdel(key,field); },
  async sadd(key,...members) { if(useMemory){memSadd(key,...members);return;} return client.sadd(key,...members); },
  async smembers(key)        { if(useMemory) return memSmembers(key); return client.smembers(key); },
  async srem(key,member)     { if(useMemory){memSrem(key,member);return;} return client.srem(key,member); },
};

// ─── ONLINE USERS ─────────────────────────────────────────
const OnlineUsers = {
  KEY: 'online:users',
  async set(userId, data) {
    await Cache.hset(this.KEY, userId, data);
    if (!useMemory && client) await client.expire(this.KEY, 86400);
  },
  async remove(userId) { await Cache.hdel(this.KEY, userId); },
  async getAll() {
    const raw = await Cache.hgetall(this.KEY);
    if (!raw) return {};
    const result = {};
    for (const [k, v] of Object.entries(raw)) {
      try { result[k] = typeof v === 'object' ? v : JSON.parse(v); } catch { result[k] = v; }
    }
    return result;
  },
  async count() { return Object.keys(await this.getAll()).length; },
};

// ─── SESSION CACHE ────────────────────────────────────────
const SessionCache = {
  async set(token, data)  { await Cache.set(`session:${token}`, data, 86400); },
  async get(token)        { return Cache.get(`session:${token}`); },
  async del(token)        { return Cache.del(`session:${token}`); },
};

module.exports = { initRedis, getClient, getSubscriber, Cache, OnlineUsers, SessionCache };
