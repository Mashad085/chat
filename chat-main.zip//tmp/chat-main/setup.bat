@echo off
title ChatApp Setup
color 0A
echo.
echo  ========================================
echo    ChatApp - Setup Windows
echo  ========================================
echo.

:: Check Node.js
node -v >nul 2>&1
if errorlevel 1 (
    echo  [ERROR] Node.js belum terinstall!
    echo  Download dari: https://nodejs.org
    echo  Pilih versi LTS lalu install, kemudian jalankan ulang script ini.
    pause
    exit /b 1
)

echo  [OK] Node.js ditemukan:
node -v
echo.

:: Copy .env if not exists
if not exist ".env" (
    copy "1.env.1" ".env" >nul
    echo  [OK] File .env dibuat dari template
) else (
    echo  [OK] File .env sudah ada
)
echo.

:: Install dependencies
echo  [INFO] Menginstall dependencies (npm install)...
echo  Ini mungkin butuh beberapa menit...
echo.
call npm install
if errorlevel 1 (
    echo.
    echo  [ERROR] npm install gagal!
    pause
    exit /b 1
)
echo.
echo  [OK] Dependencies berhasil diinstall
echo.

:: Done
echo  ========================================
echo    Setup selesai! Jalankan start.bat
echo  ========================================
echo.
pause
